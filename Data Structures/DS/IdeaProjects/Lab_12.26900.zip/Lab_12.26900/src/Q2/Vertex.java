package Q2;

class Vertex {
    int label;
    boolean visited;

    Vertex(int label) {
        this.label = label;
        this.visited = false;
    }
}