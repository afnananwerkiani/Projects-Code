public class Main
{
    public static void main(String[] args) {
        MazeSolver maze = new MazeSolver();
    }
}
